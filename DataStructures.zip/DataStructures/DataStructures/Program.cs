﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace DataStructures
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to data structures.");
            Console.WriteLine("What type of structure would you like to use?");
            Console.WriteLine(" ");
            Console.WriteLine("1. Array");
            Console.WriteLine("2. Map");
            Console.WriteLine("3. Stack");
            Console.WriteLine("4. queue");
            Console.WriteLine("5. end program");
            int userResponse = Convert.ToInt32(Console.ReadLine());

            //array
            // better to store a fixed-size collection of elements
            string[] weekDays = new string[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };

            //map
            // used for higher order functions
            var map = new Dictionary<string, string>();
            map.Add("Sunday","Monday");
            map.Add("Tuesday", "Wednesday");
            map.Add("Thursday", "Friday");
            map.Add("Saturday", "End.");

            //stack
            //pushes and pops elements
            //follows last in, first out
            Stack<string> weekdaysU = new Stack<string>();
            weekdaysU.Push("Sunday");
            weekdaysU.Push("Monday");
            weekdaysU.Push("Tuesday");
            weekdaysU.Push("Wednesday");
            weekdaysU.Push("Thursday");
            weekdaysU.Push("Friday");
            weekdaysU.Push("Saturday");

            //queue
            //when items dont need to be processed immediately
            //first in, first out
            Queue days = new Queue();
            days.Enqueue("Sunday");
            days.Enqueue("Monday");
            days.Enqueue("Tuesday");
            days.Enqueue("Wednesday");
            days.Enqueue("Thursday");
            days.Enqueue("Friday");
            days.Enqueue("Saturday");

            if (userResponse == 1)
            {
                foreach (var item in weekDays)
                {
                    Console.WriteLine(item);
                }
                Console.ReadLine();
            }
            else if (userResponse == 2)
            {
                foreach (var pair in map)
                {
                    string key = pair.Key;
                    string value = pair.Value;
                    Console.WriteLine(key + "/" + value);
                }
                Console.ReadLine();
            }
            else if (userResponse == 3)
            {
                foreach (string str in weekdaysU)
                {
                    Console.WriteLine(str);
                }
                Console.ReadLine();
            }
            else if (userResponse == 4)
            {
                foreach (var ele in days)
                {
                    Console.WriteLine(ele);
                }
                Console.ReadLine();
            }
            else if (userResponse == 5)
            {
                System.Environment.Exit(1);
            }
        }
    }
}
